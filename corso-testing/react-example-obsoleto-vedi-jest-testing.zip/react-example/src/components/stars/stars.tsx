import '../../App.css';

function Stars() {
    return (
        <div className="App">*****</div>
    );
}

export { Stars };
