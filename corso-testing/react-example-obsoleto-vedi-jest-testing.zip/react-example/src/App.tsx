import './App.css';
import { Selector } from './components/selector/selector';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Selector title="Selettore" />
      </header>
    </div>
  );
}

export default App;
